﻿                       Tibetan Machine Uni Font 1.901
                             October, 2007
                             
                           THDL (www.thdl.org)
                           
Use of this font file is covered by the General Public License included as gpl.txt within the download
zip file.

Many thanks to Chris Fynn whose skill and effort helped make this release possible.

This is the latest fully updated version of the Tibetan Machine Unicode font, known as "Tibetan Machine Uni".
It supercedes previous releases of this font and should replace them.

NOTE: This font file has a different name than the previous version of the font. Therefore, the previous
      version must first be uninstalled prior to installing this one. To uninstall, the previous version
      on a PC. Go to your font folder (usually Start Menu --> Control Panel --> Fonts). Find the Tibetan
      Machine Uni Font file. Right click on it and choose delete.